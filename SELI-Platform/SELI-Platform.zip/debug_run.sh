#!/bin/bash
meteor --port 3002 --settings .deploy/settings.json
