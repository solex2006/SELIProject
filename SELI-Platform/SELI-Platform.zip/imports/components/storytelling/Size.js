/* import React, { Component } from 'react';
import windowSize from 'react-window-size';
 
class Size extends Component {
componentDidMount(){
    this.props.size(this.props.windowWidth, this.props.windowHeight)
    
}
   

  render() {
    return (
      <p>
        Screen width is: {this.props.windowWidth}
        <br />
        Screen height is: {this.props.windowHeight}
      </p>
    );
  }
 
}
 
export default windowSize(Size); */